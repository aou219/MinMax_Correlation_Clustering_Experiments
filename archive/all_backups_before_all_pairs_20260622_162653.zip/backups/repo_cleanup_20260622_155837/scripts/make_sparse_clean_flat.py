import argparse
import csv
from pathlib import Path


DEFAULT_INPUT = Path("results/processed/all_runs_flat.csv")
DEFAULT_OUTPUT = Path("results/processed/all_runs_flat_sparse_clean.csv")


DROP_COLUMNS = {
    "file_name",
    "graph_family",
    "complete_pivot_best_cost",
    "complete_bad_triangles_min_disjoint",
    "complete_dual_cost",
    "complete_best_pivot_approx",
    "complete_average_pivot_approx",
    "complete_bad_triangle_primal_ratio",
    "complete_bad_triangle_dual_ratio",
    "complete_min_disjoint_bad_triangle_ratio",
    "complete_max_disjoint_bad_triangle_ratio",
    "edge_pivot_best_cost",
    "edge_bad_triangles_min_disjoint",
    "same_clustering_4_cycle",
    "edge_dual_cost",
    "edge_best_pivot_approx_with4",
    "edge_average_pivot_approx_with4",
    "edge_bad_triangle_primal_ratio",
    "edge_bad_triangle_dual_ratio",
    "edge_min_disjoint_bad_triangle_ratio",
    "edge_max_disjoint_bad_triangle_ratio",
}


RENAME_COLUMNS = {
    "complete_ilp_cost": "complete_sparse_ilp_cost",
    "complete_lp_cost": "complete_sparse_lp_cost",
    "complete_lp_ratio": "complete_sparse_lp_to_ilp_ratio",
    "complete_primal_cost": "complete_bad_triangle_lp_primal_cost",
    "edge_ilp_without4_cost": "edge_sparse_ilp_without4_cost",
    "edge_ilp_with4_cost": "edge_sparse_ilp_with4_cost",
    "edge_lp_without4_cost": "edge_sparse_lp_without4_cost",
    "edge_lp_with4_cost": "edge_sparse_lp_with4_cost",
    "edge_lp_ratio_with4": "edge_sparse_lp_to_ilp_ratio_with4",
    "edge_primal_cost": "edge_bad_triangle_lp_primal_cost",
}


def parse_args():
    parser = argparse.ArgumentParser(
        description=(
            "Create a compact sparse-results CSV without changing the original."
        )
    )
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    return parser.parse_args()


def main():
    args = parse_args()

    if not args.input.exists():
        raise SystemExit(f"Input does not exist: {args.input}")

    if args.output.exists():
        raise SystemExit(
            f"Output already exists and was not overwritten: {args.output}\n"
            "Choose another path with --output."
        )

    with args.input.open(newline="") as input_file:
        reader = csv.DictReader(input_file)
        original_columns = reader.fieldnames or []
        rows = list(reader)

    missing_rename_columns = sorted(set(RENAME_COLUMNS) - set(original_columns))
    if missing_rename_columns:
        raise SystemExit(
            "Expected columns are missing: " + ", ".join(missing_rename_columns)
        )

    output_columns = [
        RENAME_COLUMNS.get(column, column)
        for column in original_columns
        if column not in DROP_COLUMNS
    ]

    cleaned_rows = []
    for row in rows:
        cleaned_rows.append(
            {
                RENAME_COLUMNS.get(column, column): value
                for column, value in row.items()
                if column not in DROP_COLUMNS
            }
        )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", newline="") as output_file:
        writer = csv.DictWriter(output_file, fieldnames=output_columns)
        writer.writeheader()
        writer.writerows(cleaned_rows)

    print(f"Original preserved: {args.input}")
    print(f"Clean CSV created: {args.output}")
    print(f"Rows: {len(cleaned_rows)}")
    print(f"Columns: {len(original_columns)} -> {len(output_columns)}")
    print("Kept LP/ILP ratios:")
    print("- complete_sparse_lp_to_ilp_ratio")
    print("- edge_sparse_lp_to_ilp_ratio_with4")


if __name__ == "__main__":
    main()
